#include <stdio.h>
#include <stdlib.h>
#include <omp.h>



void generate_random(double *input, size_t size)
{
  #pragma omp parallel for

  for (size_t i = 0; i < size; i++) {
    input[i] = rand() / (double)(RAND_MAX);
  }
}



#ifndef MAX_THREADS
#define MAX_THREADS 32
#endif

#ifndef CACHE_LINE_SIZE
#define CACHE_LINE_SIZE 64
#endif

typedef struct {
    double sum;
    char pad[CACHE_LINE_SIZE - sizeof(double)];
} PaddedDouble;

double omp_local_sum(double *x, size_t size)
{
  double start_time, end_time;
  static PaddedDouble local[MAX_THREADS] = {0.0};
  double total_sum_val = 0.0;

  start_time = omp_get_wtime();
  
  #pragma omp parallel shared (local)
  {
    int thread_id = omp_get_thread_num();

    #pragma omp for
    for (size_t i = 0; i < size; ++i) {
        local[thread_id].sum += x[i];
    }
  }
    
  for (int i = 0; i < MAX_THREADS; i++) {
    total_sum_val += local[i].sum;
  }

  end_time = omp_get_wtime();

  printf("Execution time with scheduling: %f seconds\n", end_time - start_time);
    
  

  return total_sum_val;
}

int main(int argc, char **argv) {

  if(argc < 2){
    printf("!!\tERROR: Expected 1 argument, got %d\n", argc - 1);
    return 1;
  }

  int N = atoi(argv[1]);

  double *n_input = (double *)malloc(N * sizeof(double));

  generate_random(n_input, N); 

  omp_local_sum(n_input, N); 
}